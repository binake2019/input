import cv2 as cv
import pyautogui as pag
import torch
import matplotlib.pyplot as plt
from torch import nn,optim
import torch.nn.functional as F
import os
import time



d = 25

def restart():
    pag.click(330,185)
    pag.click(518,598)
    
def isEnd():
    box = pag.locateOnScreen('end.png',region=(320,172,28,28))
    if box:
        return 1
    else:
        return 0 

def getScreen():
    image = pag.screenshot(region=(119,157,430,470))
    image.save('minefields.png')

    img = cv.imread('minefields.png')
    return img

def getCenter(cnt):
    x = int(cv.moments(cnt)['m10']/cv.moments(cnt)['m00'])
    y = int(cv.moments(cnt)['m01']/cv.moments(cnt)['m00'])
    return x,y

def getNum(ps):
    ls = [-1,1,2,3,4,5,8]
    reg = (ps[0] - 13,ps[1] - 13,27,27)
    num = 0
    for i in ls:
        box = pag.locateOnScreen(str(i)+'.png',region=reg)
        if box:
            num = i
            break
    return num


def getPS(np):
        
    p1 = (np[0] - d , np[1] - d)
    p2 = (np[0]     , np[1] - d)
    p3 = (np[0] + d , np[1] - d)
        
    p4 = (np[0] - d , np[1])
    #p5 = np
    p6 = (np[0] + d , np[1])
        
    p7 = (np[0] - d , np[1] +d)
    p8 = (np[0]     , np[1] +d)
    p9 = (np[0] + d , np[1] +d)
        
    return p1,p2,p3,p4,p6,p7,p8,p9
    
def getXL(np):
    ls = []
    #pag.moveTo(100,100)
    ls1 = getPS(np)
    for i in ls1:
        ls.append(getNum(i))
    return ls

def getTure(ls):
    ps = pag.position()
    ls_ps = getPS(ps)
    for i in len(ls):
        if ls[i] == -1:
            pag.click(ls_ps[i])

def isMine(ps):
    pag.click(ps)
    pag.moveTo(100,100)
    if pag.locateOnScreen('redmine.png',region=(ps[0]-d,ps[1]-d,d*2,d*2)):
        print("这个方块是雷")
        return 1
    else:
        print("不是雷")
        return 0
#----------------------------------------


pag.PAUSE = 0.1
pag.moveTo(100,100)

def checkTwo():
    t = pag.locateAllOnScreen('-1.png',region=(320,172,28,28))
    for box in t:
        print(box)
        ps = (box.left+d/2, box.top+ d/2)
        ls = getXL(np)
        cc = 0
        for m in ls:
            if m > 0:
                cc = cc +1 
        if cc >2:
            return(np)






    
#点开一个未打开的方框,返回该方框为中心的9个格子信息.
def checkOne():
    img = getScreen()
    ##cv.imshow('minefields',img)

    # 灰度图
    gray = cv.cvtColor(img,cv.COLOR_BGR2GRAY)
    ##cv.imshow('gray',gray)

    th1 = cv.adaptiveThreshold(gray,255,cv.ADAPTIVE_THRESH_GAUSSIAN_C,
                               cv.THRESH_BINARY,5,2)
    #cv.imshow('th1',th1)

    contours,hier = cv.findContours(th1,cv.RETR_LIST,cv.CHAIN_APPROX_SIMPLE)


    d = 25 # 方块边长

    for cnt in contours:
        if isEnd():
            print("踩雷结束")
            break
        dst = img.copy()
        dst = cv.drawContours(dst,cnt,-1,(0,255,0),1)

        x,y,w,h = cv.boundingRect(cnt)
        dst = cv.rectangle(dst,(x,y), (x+w,y+h),(0,0,255),2)
        area = w*h

        if 410 > area > 380:
            cv.waitKey(200)
            a,b = getCenter(cnt)
            np = (119+a+5,157+b+5)
            ls = getXL(np)
            cc = 0
            for m in ls:
                if m > 0:
                    cc = cc +1 
            if cc >2:
                return(np)

            


# 初始化

class Net(nn.Module):
    def __init__(self,hidden_in,hidden_num,outputs):
        super(Net,self).__init__()
        self.hidden = nn.Linear(hidden_in,hidden_num)
        self.out = nn.Linear(hidden_num,outputs)

    def forward(self,x):
        x = F.relu(self.hidden(x))
        x = self.out(x)
        x = F.softmax(x)
        return x

#创建net
if os.path.exists('net.pkl'):
    net = torch.load('net.pkl')
else:
    net = Net(hidden_in=8,hidden_num=10,outputs=2)


#定义交叉熵函数
criterion = nn.CrossEntropyLoss ()
#定义优化器
optimizer = optim.SGD(net.parameters(),lr =0.02)



# 训练
def train(model,criterion,optimizer,epochs):
    #正确次数
    rt = 0
    f = open('traindata.txt','a',encoding='utf-8')
    for i in range(epochs):
        print("-"*15)
        if isEnd():
            restart()
        time.sleep(0.5)
        ps = checkTwo()
        ls = getXL(ps)
        inputs = torch.tensor(ls, dtype=torch.float)
        inputs = inputs.unsqueeze(0)
        output = model(inputs)
        pre_y = torch.max(output,1)[1].numpy()
        if pre_y[0] == 1:
            pag.click(ps,button='right')
            continue
        flag = isMine(ps)    
        target = torch.tensor([flag], dtype=torch.long)
        #print('target_size',target.size())
        lsw = []
        for a in ls:
            lsw.append(str(a))
        lsw.append(str(flag))
        f.write(",".join(lsw))
        f.write("\n")

        # ls 为输入数据，flag为结果

        #print("output_size",output.size())

        print("预测结果",pre_y)
        if pre_y[0] == flag:
            print("预测正确")
            rt = rt + 1
        loss = criterion(output,target)
        print("loss",loss)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    f.close()
    torch.save(model,'net.pkl')
    print("正确率",rt/epochs)



train(net,criterion,optimizer,100)



















        
