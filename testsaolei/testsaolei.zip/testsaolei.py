import cv2 as cv
import pyautogui as pag



def getScreen():
    image = pag.screenshot(region=(119,157,430,470))
    image.save('minefields.png')

    img = cv.imread('minefields.png')
    return img

def getCenter(cnt):
    x = int(cv.moments(cnt)['m10']/cv.moments(cnt)['m00'])
    y = int(cv.moments(cnt)['m01']/cv.moments(cnt)['m00'])
    return x,y


#----------------------------------------


##pag.PAUSE = 0.5
pag.moveTo(100,100)


img = getScreen()
##cv.imshow('minefields',img)

# 灰度图
gray = cv.cvtColor(img,cv.COLOR_BGR2GRAY)
##cv.imshow('gray',gray)

th1 = cv.adaptiveThreshold(gray,255,cv.ADAPTIVE_THRESH_GAUSSIAN_C,
                           cv.THRESH_BINARY,5,2)
##cv.imshow('th1',th1)

contours,hier = cv.findContours(th1,cv.RETR_LIST,cv.CHAIN_APPROX_SIMPLE)

for cnt in contours:
    dst = img.copy()
    dst = cv.drawContours(dst,cnt,-1,(0,255,0),1)
##    cv.imshow("rect",dst)

    x,y,w,h = cv.boundingRect(cnt)
    dst = cv.rectangle(dst,(x,y), (x+w,y+h),(0,0,255),2)
    area = w*h

    print(area)
    if 410 > area > 380:
        print(type(cnt))
##        cv.imshow('dst',dst)
        cv.waitKey(200)
        a,b = getCenter(cnt)
        pag.moveTo(119+a,157+b)
        pag.click()
        
